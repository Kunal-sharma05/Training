package com.hexaware.restdemo.bean;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	@GetMapping("/getStudent")
	public Student getStudent()
	{
		return (new Student(100,"Kunal","Sharma"));
	}
	@GetMapping("/getStudentList")
	public List<Student> getStudentList()
	{
		List<Student> myList = new ArrayList<>();
		myList.add(new Student(100,"Kunal","Sharma"));
		myList.add(new Student(101,"Rahul","Sharma"));
		myList.add(new Student(102,"Abhishek","Sharma"));
		myList.add(new Student(103,"Sayooj","Sharma"));
		
		return myList;
	}
	//path variable 
	@GetMapping("/getStudentbyid/{id}")
	public Student getStudentById(@PathVariable int id)
	{
		List<Student> myList = new ArrayList<>();
		Student st=null;
		myList.add(new Student(100,"Kunal","Sharma"));
		myList.add(new Student(101,"Rahul","Sharma"));
		myList.add(new Student(102,"Abhishek","Sharma"));
		myList.add(new Student(103,"Sayooj","Sharma"));
		for(Student student:myList)
		{
			if(student.getId()==id)
			{
				st=student;
				break;
			}
		}
		return st;
	}
	// return a single object created by passing value from url
	@GetMapping("/getStudentusingsuppliedargs/{id}/{fname}/{lname}")
	public Student getStudentUsingsuppliedargs(
	        @PathVariable("id") int studentId,
	        @PathVariable("fname") String firstName,
	        @PathVariable("lname") String lastName)
	{
		return (new Student(studentId,firstName,lastName));
	}
	// @request Param or queryparam getting deatail
	@GetMapping("/getStudentbyidreqparam/{id}")
	public Student getStudentByIdReqParam(@RequestParam int id)
	{
		List<Student> myList = new ArrayList<>();
		Student st=null;
		myList.add(new Student(100,"Kunal","Sharma"));
		myList.add(new Student(101,"Rahul","Sharma"));
		myList.add(new Student(102,"Abhishek","Sharma"));
		myList.add(new Student(103,"Sayooj","Sharma"));
		for(Student student:myList)
		{
			if(student.getId()==id)
			{
				st=student;
				break;
			}
		}
		return st;
	}
	//http://localhost:8080/getStudentusingsuppliedargsreqparams?id=100&fname=Kunal&lname=Sharma
	@GetMapping("/getStudentusingsuppliedargsreqparams")
	public Student getStudentUsingsuppliedargsreqparams(
	        @RequestParam(name="id",defaultValue="100") int studentId,
	        @RequestParam("fname") String firstName,
	        @RequestParam("lname") String lastName,@RequestParam(required=false) String op)
	        
	{
		return (new Student(studentId,firstName,lastName));
	}
	
	//PostMapping
	// Print the student entity used for saving the entity in d
	@PostMapping("/saveStudent")
	@ResponseStatus(HttpStatus.CREATED)
	public Student createStudent(@RequestBody Student s) {
		System.out.println(s);
		return s;
		}
	// used for updating
	@PutMapping("/updateStudent/{id}")
    public Student updateStudent(@PathVariable("id") int id, @RequestBody Student s) {
        List<Student> myList = new ArrayList<>();
        myList.add(new Student(101, "Rahul", "KR"));
        myList.add(new Student(102, "Sowmya", "T"));
        myList.add(new Student(103, "Laja", "S"));

        for (int i = 0; i < myList.size(); i++) {
            if (myList.get(i).getId() == id) {
                myList.set(i, s);
                break;
            }
        }
        System.out.println(s);
        return s;
    }

}


