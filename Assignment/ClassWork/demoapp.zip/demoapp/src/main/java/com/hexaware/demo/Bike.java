package com.hexaware.demo;


public class Bike implements IVehicle {
	public void move()
	{
		System.out.println("Bike is moving");
	}

}
