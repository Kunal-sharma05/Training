package com.hexaware.demo;

public class Cycle implements IVehicle {

		public void move()
		{
			System.out.println("Cycle is moving");
		}

	}


