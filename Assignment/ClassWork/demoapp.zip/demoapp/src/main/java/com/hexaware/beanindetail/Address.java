package com.hexaware.beanindetail;

public class Address {
	void print() {
		System.out.println("address is showed");
	}

}
