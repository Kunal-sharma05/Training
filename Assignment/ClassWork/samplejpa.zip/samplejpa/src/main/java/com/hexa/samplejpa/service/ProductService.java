package com.hexa.samplejpa.service;

import java.util.List;

import com.hexa.samplejpa.entity.Product;

public interface ProductService {
	List<Product> searchProducts(String query);
	public Product creatProduct(Product p);
}
