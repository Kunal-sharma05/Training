package com.hexa.samplejpa.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.samplejpa.entity.Product;
import com.hexa.samplejpa.repository.ProductRepository;
import com.hexa.samplejpa.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	private ProductRepository productRepository;
	@Autowired
	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}
	public ProductServiceImpl() {
		super();
	}
	@Override
	public List<Product> searchProducts(String query) {
		// TODO Auto-generated method stub
		List<Product> productList=productRepository.searchProducts(query);
		return productList;
	}
	@Override
	public Product creatProduct(Product p) {
		// TODO Auto-generated method stub
		return productRepository.save(p);
	}

}
