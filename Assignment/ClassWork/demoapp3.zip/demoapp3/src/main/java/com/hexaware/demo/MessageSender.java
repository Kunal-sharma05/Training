package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("messageSender")
public class MessageSender {

	IMessageService obj1=null;
	IMessageService obj2=null;
	@Autowired
	public MessageSender(@Qualifier("smsService")IMessageService t,@Qualifier("emailService") IMessageService e)// we can also use @Primary qualifier at the place of component class only;
	{
		this.obj1=t;
		System.out.println("constructor inject Bean for SMSService: " +this.obj1);
		this.obj2=e;
		System.out.println("constructor inject Bean for SMSService: " +this.obj2);
		
		
	}
	public void send(String message, String medium)
	{
		if(medium.equalsIgnoreCase("sms"))
		{
			obj1.sendMessage(message);
		}
		else
		{
			obj2.sendMessage(message);
		}
	}
}
