package com.hexaware.demo;

public interface IMessageService {
	public void sendMessage(String message);

}
