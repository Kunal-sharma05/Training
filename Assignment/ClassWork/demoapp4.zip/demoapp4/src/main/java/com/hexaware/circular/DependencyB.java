package com.hexaware.circular;

public class DependencyB {
	private DependencyA da;

	/*
	 * public DependencyB(DependencyA da) { super(); this.da = da; }
	 */

	public DependencyA getDa() {
		return da;
	}

	public void setDa(DependencyA da) {
		this.da = da;
	}

}
