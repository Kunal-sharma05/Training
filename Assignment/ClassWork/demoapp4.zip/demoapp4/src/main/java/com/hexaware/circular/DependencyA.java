package com.hexaware.circular;

public class DependencyA {
	public DependencyB getDb() {
		return db;
	}

	public void setDb(DependencyB db) {
		this.db = db;
	}

	private DependencyB db;

	/*
	 * public DependencyA(DependencyB db) { super(); this.db = db; }
	 */

}
