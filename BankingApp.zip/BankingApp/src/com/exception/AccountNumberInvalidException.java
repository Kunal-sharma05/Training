package com.exception;

public class AccountNumberInvalidException extends Exception{
	    private String message;

	    public AccountNumberInvalidException() {
	        super();
	        this.message = "Account number Invalid";
	    }

	    public AccountNumberInvalidException(String message) {
	        super(message + " Account number Invalid");
	    }

}
